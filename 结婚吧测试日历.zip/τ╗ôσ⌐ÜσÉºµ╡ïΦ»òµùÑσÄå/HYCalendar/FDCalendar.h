//
//  FDCalendar.h
//  CalendarDemo
//
//  Created by admin on 16/7/5.
//  Copyright (c) 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FDCalendar : UIView

- (instancetype)initWithCurrentDate:(NSData *)data;

@end
