//
//  MyCalendarItem.m
//  HYCalendar
//
//  Created by nathan on 14-9-17.
//  Copyright (c) 2014年 nathan. All rights reserved.
//

#import "MyCalendarItem.h"


@implementation MyCalendarItem
{
    UIButton  *_selectButton;   // 选中按钮
    UILabel *_circleL;   // 选中圆圈
    NSMutableArray *_daysArray;   // day 是否可点击的按钮数组
    NSMutableArray *_circleArr;   // 选中圆圈数组
    
    UILabel *_headlabel;
    UILabel *_headlabelmoth;
    
    //UIButton*lastChooseBtn;//上一个选中的按钮
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        _daysArray = [NSMutableArray arrayWithCapacity:42];
        _circleArr = [NSMutableArray arrayWithCapacity:42];
        
        for (int i = 0; i < 42; i++) {
            
            
            UIButton *button = [[UIButton alloc] init];
           // [self addSubview:button];
            [_daysArray addObject:button];
            
            UILabel *circleL = [[UILabel alloc] init];
            //[self addSubview:circleL];
            [_circleArr addObject:circleL];
            
        }
    }
    
    return self;
}


#pragma mark - date 获取日历
//日
- (NSInteger)day:(NSDate *)date{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
    NSLog(@"aaaaaaa=%ld",[components day]);
    return [components day];
    
    
    

}

//月
- (NSInteger)month:(NSDate *)date{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
    return [components month];
}

//年
- (NSInteger)year:(NSDate *)date{
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
    return [components year];
}

//本月第一天星期几
- (NSInteger)firstWeekdayInThisMonth:(NSDate *)date{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar setFirstWeekday:1];//1.Sun. 2.Mon. 3.Thes. 4.Wed. 5.Thur. 6.Fri. 7.Sat.
    NSDateComponents *comp = [calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
    [comp setDay:1];
    NSDate *firstDayOfMonthDate = [calendar dateFromComponents:comp];
    NSUInteger firstWeekday = [calendar ordinalityOfUnit:NSCalendarUnitWeekday inUnit:NSCalendarUnitWeekOfMonth forDate:firstDayOfMonthDate];
    
    return firstWeekday - 1;
}

//本月总共天数
- (NSInteger)totaldaysInMonth:(NSDate *)date{
    NSRange daysInOfMonth = [[NSCalendar currentCalendar] rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:date];
    NSLog(@"天数=%ld",daysInOfMonth.length);
    return daysInOfMonth.length;
}

//上个月
- (NSDate *)lastMonth:(NSDate *)date{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    dateComponents.month = -1;
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:date options:0];
    return newDate;
}

//下个月
- (NSDate*)nextMonth:(NSDate *)date{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    dateComponents.month = +1;
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:date options:0];
    return newDate;
}

//上一年
- (NSDate *)lastYear:(NSDate *)date {
    
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    dateComponents.year = -1;
    
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:date options:0];
    
    return newDate;
}

//下一年
- (NSDate *)nextYear:(NSDate *)date {
    
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    dateComponents.year = +1;
    
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:date options:0];
    
    return newDate;
}



#pragma mark - create View
- (void)setDate:(NSDate *)date{
    
    _date = date;
    
    [self createCalendarViewWith:date];
}

- (void)createCalendarViewWith:(NSDate *)date{

    CGFloat itemW     = self.frame.size.width / 7;
    CGFloat itemH     = self.frame.size.height / 8;
    
    
    
    
    // 1.year month
    _headlabel = [[UILabel alloc] init];
//    headlabel.text     = [NSString stringWithFormat:@"%li年%li月",[self year:date],[self month:date]];
    
    _headlabel.text     = [NSString stringWithFormat:@"%li",[self year:date]];
    _headlabel.font     = [UIFont systemFontOfSize:14];
    _headlabel.frame           = CGRectMake(0, 0, self.frame.size.width/2,30);
    _headlabel.textAlignment   = NSTextAlignmentCenter;
    _headlabel.backgroundColor = [UIColor colorWithRed:0.95 green:0.91 blue:0.92 alpha:1.00];
    [self addSubview:_headlabel];
    
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(10, 0, 30, 30);
    [btn setImage:[UIImage imageNamed:@"Laft"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(setLastYear:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(self.frame.size.width/2-40, 0, 30, 30);
    [btn2 setImage:[UIImage imageNamed:@"Right"] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(setNextYear:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn2];
    
    
    // 1.year month
    _headlabelmoth = [[UILabel alloc] init];
    //    headlabel.text     = [NSString stringWithFormat:@"%li年%li月",[self year:date],[self month:date]];
    
    _headlabelmoth.text = [NSString stringWithFormat:@"%li月",[self month:date]];
    _headlabelmoth.textColor = [UIColor colorWithRed:0.98 green:0.36 blue:0.53 alpha:1.00];
    _headlabelmoth.font = [UIFont systemFontOfSize:14];
    _headlabelmoth.frame = CGRectMake(self.frame.size.width/2, 0, self.frame.size.width/2,30);
    _headlabelmoth.textAlignment   = NSTextAlignmentCenter;
    _headlabelmoth.backgroundColor = [UIColor colorWithRed:0.95 green:0.91 blue:0.92 alpha:1.00];
    [self addSubview:_headlabelmoth];
    
    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn3.frame = CGRectMake(self.frame.size.width/2+10, 0, 30, 30);
    [btn3 setImage:[UIImage imageNamed:@"Laft"] forState:UIControlStateNormal];
    [btn3 addTarget:self action:@selector(setLastMonth:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn3];
    
    UIButton *btn24 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn24.frame = CGRectMake(self.frame.size.width-40, 0, 30, 30);
    [btn24 setImage:[UIImage imageNamed:@"Right"] forState:UIControlStateNormal];
    [btn24 addTarget:self action:@selector(setNextMonth:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:btn24];
    
    
    
    
    // 2.weekday
    NSArray *array = @[@"日", @"一", @"二", @"三", @"四", @"五", @"六"];
    UIView *weekBg = [[UIView alloc] init];
    weekBg.backgroundColor = [UIColor colorWithRed:0.95 green:0.91 blue:0.92 alpha:1.00];
    weekBg.frame = CGRectMake(0, CGRectGetMaxY(_headlabel.frame), self.frame.size.width, itemH);
    [self addSubview:weekBg];
    
    for (int i = 0; i < 7; i++) {
        UILabel *week = [[UILabel alloc] init];
        if (i==0||i==6) {
            week.textColor = [UIColor colorWithRed:0.96f green:0.61f blue:0.71f alpha:1.00f];
        }
        week.text     = array[i];
        week.font     = [UIFont systemFontOfSize:14];
        week.frame    = CGRectMake(itemW * i, 0, itemW, 32);
        week.textAlignment   = NSTextAlignmentCenter;
        week.backgroundColor = [UIColor clearColor];
   
        [weekBg addSubview:week];
    }
    
    
    //  3.days (1-31)
    for (int i = 0; i < 42; i++) {
        int x = (i % 7) * itemW ;
        int y = (i / 7) * itemH + CGRectGetMaxY(weekBg.frame);
        
        UIButton *dayButton = _daysArray[i];
        dayButton.frame = CGRectMake(x, y, itemW, itemH);
        dayButton.titleLabel.font = [UIFont systemFontOfSize:14.0];
        dayButton.titleLabel.textAlignment = NSTextAlignmentCenter;
        dayButton.layer.cornerRadius = 5.0f;
        [dayButton setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
        
        [dayButton addTarget:self action:@selector(logDate:) forControlEvents:UIControlEventTouchUpInside];
        dayButton .titleLabel.numberOfLines=0;
        [self addSubview:dayButton];
        
        _circleL = _circleArr[i];
        CGFloat max=itemW>itemH?itemH:itemW;
        CGFloat min=itemW<itemH?itemH:itemW;
        _circleL.frame = CGRectMake(0,0,max+10,max+10);
        _circleL.hidden = YES;
        _circleL.layer.cornerRadius = max/2+5;
        _circleL.layer.borderWidth = 1;
        _circleL.center = CGPointMake(0+min/2, 0+min/2);
        _circleL.layer.borderColor = [[UIColor colorWithRed:0.98 green:0.36 blue:0.53 alpha:1.00] CGColor];
        _circleL.tag=i;
        _circleL.hidden=YES;
        [dayButton addSubview:_circleL];
       
        
        
        
        NSInteger daysInLastMonth = [self totaldaysInMonth:[self lastMonth:date]];
        NSInteger daysInThisMonth = [self totaldaysInMonth:date];
        NSInteger firstWeekday    = [self firstWeekdayInThisMonth:date];
        NSLog(@"1= %ld,2=%ld, 3=%ld",daysInLastMonth,daysInThisMonth,firstWeekday);
        
        if ( i==[self day:date]+[self firstWeekdayInThisMonth:date]-1) {
            dayButton.selected=YES;
            _selectButton=dayButton;
            UILabel*lastLabe=_selectButton.subviews[1];
            lastLabe.hidden=NO;
        }
        
        NSInteger day = 0;
        
        if (i < firstWeekday) {
            
            day = daysInLastMonth - firstWeekday + i + 1;
            [self setStyle_BeyondThisMonth:dayButton];
            
            
        }else if (i > firstWeekday + daysInThisMonth - 1){
            
            day = i + 1 - firstWeekday - daysInThisMonth;
            [self setStyle_BeyondThisMonth:dayButton];
            
        }else{
            
            day = i - firstWeekday + 1;
            [self setStyle_AfterToday:dayButton];
            
        }
        
        [dayButton setTitle:[NSString stringWithFormat:@"%li", day] forState:UIControlStateNormal];
        
        
        
#pragma mark - 添加吉日数据
        // 获取日期
        NSString *straray = [NSString stringWithFormat:@"%li-%li-%ld",[self year:date],[self month:date],day];
        NSLog(@"straray=%@",straray);
        
        for (int i=0; i<_arraydata.count; i++) {
            
            if ([_arraydata[i] isEqualToString:straray]&&dayButton.enabled==YES) {
                
                UILabel *labrl = [[UILabel alloc]init];
                labrl.frame =CGRectMake(dayButton.frame.origin.x, dayButton.frame.origin.y+itemH/2+itemH/5, dayButton.bounds.size.width, 10);
                labrl.textColor = [UIColor colorWithRed:0.98 green:0.36 blue:0.53 alpha:1.00];
                labrl.text = @"吉日";
                labrl.font = [UIFont systemFontOfSize:9];
                labrl.textAlignment = NSTextAlignmentCenter;
                [self addSubview:labrl];
                
                
            }
        }


      
        
        
        // this month
        if ([self month:date] == [self month:[NSDate date]]) {
            
            NSInteger todayIndex = [self day:date] + firstWeekday - 1;
            
            if (i < todayIndex && i >= firstWeekday) {
                
                [self setStyle_BeforeToday:dayButton];
            
            }else if(i ==  todayIndex){
                
                [self setStyle_Today:dayButton];
                
            }
        }
    }
}

#pragma mark - output date
-(void)logDate:(UIButton *)dayBtn
{
    
    
    UILabel*lastLabe=_selectButton.subviews[1];
    lastLabe.hidden=YES;
    
    _selectButton.selected = NO;
    dayBtn.selected = YES;
    _selectButton = dayBtn;
    UILabel*labelaaa=dayBtn.subviews[1];
    labelaaa.hidden=NO;
    

    NSLog(@"*******");
    
    NSInteger day = [[dayBtn titleForState:UIControlStateNormal] integerValue];
    
    NSDateComponents *comp = [[NSCalendar currentCalendar] components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:self.date];
    
    if (self.calendarBlock) {
        self.calendarBlock(day, [comp month], [comp year]);
    }
}


#pragma mark - date button style
// 不属于本月的 day button
// day不可点击 设置day字体为灰
- (void)setStyle_BeyondThisMonth:(UIButton *)btn
{
   
    btn.enabled = NO;   // 不可点击
    [btn setTitleColor:[UIColor clearColor] forState:UIControlStateNormal];   // 设置字体为灰色
}

- (void)setStyle_BeforeToday:(UIButton *)btn
{
    btn.enabled = NO;
    [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
}

// today设置
- (void)setStyle_Today:(UIButton *)btn
{
    btn.enabled = YES;
    
    
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
    
}

// 今天之后的day
- (void)setStyle_AfterToday:(UIButton *)btn
{
    btn.enabled = YES;
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}




- (void)setLastYear:(UIButton *)btn {
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    NSDate *lastYearDate = [self lastYear:self.date];
    self.date = lastYearDate;
     _headlabel.text = [NSString stringWithFormat:@"%li",[self year:lastYearDate]];
    [self createCalendarViewWith:self.date];
}

- (void)setNextYear:(UIButton *)btn {
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
  
    NSDate *nextYearDate = [self nextYear:self.date];
    self.date = nextYearDate;
    _headlabel.text = [NSString stringWithFormat:@"%li",[self year:nextYearDate]];
    
    [self createCalendarViewWith:self.date];
  
    
}

- (void)setLastMonth:(UIButton *)btn {
     [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    NSDate *lastYearDate = [self lastMonth:self.date];
    self.date = lastYearDate;
    _headlabel.text = [NSString stringWithFormat:@"%li",[self year:lastYearDate]];
    [self createCalendarViewWith:self.date];
    
}

- (void)setNextMonth:(UIButton *)btn {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    NSDate *nextYearDate = [self nextMonth:self.date];
    self.date = nextYearDate;
    _headlabel.text = [NSString stringWithFormat:@"%li",[self year:nextYearDate]];
    
    [self createCalendarViewWith:self.date];

    
    
}

@end
