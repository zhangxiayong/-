//
//  ViewController.m
//  HYCalendar
//
//  Created by nathan on 14-9-27.
//  Copyright (c) 2014年 nathan. All rights reserved.
//

#import "ViewController.h"
#import "MyCalendarItem.h"
#import "FMDatabase.h"
@interface ViewController ()
{
    FMDatabase *_fmdb;
    NSMutableArray*dotaarray;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dotaarray = [[NSMutableArray alloc]init];
    NSString *newPath=[[NSBundle mainBundle] pathForResource:@"resultdhsd" ofType:@"db"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:newPath])
    {
        NSLog(@"数据库已存在");
    }
    _fmdb=[FMDatabase databaseWithPath:newPath];
    if (!_fmdb)
    {
        NSLog(@"数据库创建不成功");
    }else
    {
        if([_fmdb open])
        {
            
            NSLog(@"打开成功") ;
            NSString *sql=@"select * from result";
            FMResultSet *qureyresult=[_fmdb executeQuery:sql];
            
            while ([qureyresult next]) {
                NSString *YYYY = [qureyresult stringForColumn:@"YYYY"];
                NSString *MM = [qureyresult stringForColumn:@"MM"];
                NSString *DD = [qureyresult stringForColumn:@"DD"];
                
               
                NSString *str = [NSString stringWithFormat:@"%@-%@-%@",[qureyresult stringForColumn:@"YYYY"],[qureyresult stringForColumn:@"MM"],[qureyresult stringForColumn:@"DD"]];
//          NSLog(@"%@",str);
                [dotaarray addObject:str];
                
                
            }
            
            
        }
        
        
    }
    
//    // demo2
//    MyCalendarItem *calendarView33 = [[MyCalendarItem alloc] init];
//    calendarView33.frame = CGRectMake(10, 430, 300, 200);
//    [self.view addSubview:calendarView33];
//    calendarView33.date = [calendarView33 lastMonth:[NSDate date]];
    
    
//    NSLog(@"%@",dotaarray);
    // demo1
    MyCalendarItem *calendarView = [[MyCalendarItem alloc] init];
    calendarView.frame = CGRectMake(10, 30, 300, 300);
    calendarView.arraydata = dotaarray;
    [self.view addSubview:calendarView];
    
    
    calendarView.date = [NSDate date];
    calendarView.calendarBlock =  ^(NSInteger day, NSInteger month, NSInteger year){
        
        NSLog(@"%li-%li-%li", year,month,day);
    };

//    // demo2
//    MyCalendarItem *calendarView2 = [[MyCalendarItem alloc] init];
//    calendarView2.frame = CGRectMake(10, 230, 300, 200);
//    [self.view addSubview:calendarView2];
//    calendarView2.date = [calendarView2 nextMonth:[NSDate date]];
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
